﻿using System;

namespace Exercise9
{
    /// <summary>
    /// Exercise 9 solution 
    /// </summary>
    class MainClass
    {
        /// <summary>
        /// Demonstrates using custom classes
        /// </summary>
        /// <param name="args">command-line arguments</param>
        public static void Main(string[] args)
        {
            // create a new deck and tell the deck to print itself

            // tell the deck to shuffle and print itself

            // take the top card from the deck and print the card rank and suit

            // take the top card from the deck and print the card rank and suit
        }
    }
}
