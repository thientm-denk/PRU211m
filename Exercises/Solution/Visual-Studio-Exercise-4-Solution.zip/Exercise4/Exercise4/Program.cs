﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise4
{
    /// <summary>
    /// Exercise 4 Solution
    /// </summary>
    class Program
    {
        /// <summary>
        /// Calculates altitude change between two locations
        /// </summary>
        /// <param name="args">command-line args</param>
        static void Main(string[] args)
        {
            // get locations
            Console.Write("Enter altitude at first location:  ");
            int firstAltitude = int.Parse(Console.ReadLine());
            Console.Write("Enter altitude at second location: ");
            int secondAltitude = int.Parse(Console.ReadLine());

            // calculate and print altitude change
            int altitudeChange = secondAltitude - firstAltitude;
            Console.WriteLine();
            Console.WriteLine("Altitude change: " + altitudeChange);

            Console.WriteLine();
        }
    }
}
