﻿using System;

namespace Exercise1
{
    /// <summary>
    /// Solution for Exercise 1
    /// </summary>
    class MainClass
    {
        /// <summary>
        /// Prints names
        /// </summary>
        /// <param name="args">command-line args</param>
        public static void Main(string[] args)
        {
            // Problem 1: output name
            Console.WriteLine("My name: Dr. T");
            Console.WriteLine();

            // Problem 2: output best name or nemesis
            Console.WriteLine("My nemesis: Administrators");

            Console.WriteLine();
        }
    }
}
