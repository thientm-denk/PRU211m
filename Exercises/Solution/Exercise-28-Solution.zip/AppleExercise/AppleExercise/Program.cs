﻿using System;

namespace AppleExercise
{
    /// <summary>
    /// Exercise 4, 5, and 6 solution
    /// </summary>
    class Program
    {
        /// <summary>
        /// Tests the apple class
        /// </summary>
        /// <param name="args">command-line args</param>
        static void Main(string[] args)
        {

        }
    }
}
