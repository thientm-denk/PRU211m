﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Exercise 2 Solution
/// </summary>
public class PrintFavoriteGames : MonoBehaviour
{
	/// <summary>
	/// Use this for initialization
	/// </summary>
	void Start()
	{
        print("DiRT Rally");
        print("Assetto Corsa");
        print("Project CARS");
    }
}
