﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise3
{
    /// <summary>
    /// Exercise 3 Solution
    /// </summary>
    class Program
    {
        /// <summary>
        /// Practice declaring, assigning, and printing a variable
        /// </summary>
        /// <param name="args">command-line args</param>
        static void Main(string[] args)
        {
            // declare, assign, and print a variable
            int age;
            age = 54;
            Console.WriteLine("Age: " + age);

            Console.WriteLine();
        }
    }
}
