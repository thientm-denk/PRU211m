﻿using System;

namespace Exercise3
{
    /// <summary>
    /// Exercise 3 Solution
    /// </summary>
    class MainClass
    {
        /// <summary>
        /// Practice declaring, assigning, and printing a variable
        /// </summary>
        /// <param name="args">command-line args</param>
        public static void Main(string[] args)
        {
            // declare, assign, and print a variable
            int age;
            age = 54;
            Console.WriteLine("Age: " + age);

            Console.WriteLine();
        }
    }
}
